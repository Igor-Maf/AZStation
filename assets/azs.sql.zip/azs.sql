-- phpMyAdmin SQL Dump
-- version 3.5.2.2
-- http://www.phpmyadmin.net
--
-- Хост: 127.0.0.1
-- Время создания: Ноя 19 2014 г., 22:43
-- Версия сервера: 5.5.27
-- Версия PHP: 5.4.7

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- База данных: `azs`
--

-- --------------------------------------------------------

--
-- Структура таблицы `clients`
--

CREATE TABLE IF NOT EXISTS `clients` (
  `client_id` int(255) NOT NULL AUTO_INCREMENT,
  `client_fio` varchar(100) NOT NULL,
  `client_address` varchar(100) NOT NULL,
  `client_mail` varchar(30) NOT NULL,
  `client_number` varchar(30) NOT NULL,
  `client_scores` decimal(5,2) DEFAULT NULL,
  PRIMARY KEY (`client_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

--
-- Дамп данных таблицы `clients`
--

INSERT INTO `clients` (`client_id`, `client_fio`, `client_address`, `client_mail`, `client_number`, `client_scores`) VALUES
(2, 'Кузнецов Александр', 'г. Одесса, 10 линия, дом неизвестен', 'kuzya@mail.ru', '0637272727', 100.00),
(3, 'Килимник Александр', 'г. Одесса, Ленина 10а, кв. 71', 'sd@asd.asd', 'фывфывфыв', 0.20),
(5, 'Геворкян Игорь Сергеевич', 'г. Одесса, ул. Гайдара 10', 'knjaz@mail.ru', '0639879898', 0.79),
(6, 'Рябко Руслана Александровна', 'г. Днепропетровск, ул. Совхозная 64, 18', 'lanalegostaeva@mail.ru', '0938991276', 0.01);

-- --------------------------------------------------------

--
-- Структура таблицы `gas`
--

CREATE TABLE IF NOT EXISTS `gas` (
  `gas_id` int(255) NOT NULL AUTO_INCREMENT,
  `gas_type` varchar(30) NOT NULL,
  `gas_price` decimal(5,2) NOT NULL,
  PRIMARY KEY (`gas_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Дамп данных таблицы `gas`
--

INSERT INTO `gas` (`gas_id`, `gas_type`, `gas_price`) VALUES
(1, 'A-92', 16.99),
(2, 'A-95', 17.99);

-- --------------------------------------------------------

--
-- Структура таблицы `gift`
--

CREATE TABLE IF NOT EXISTS `gift` (
  `gift_id` int(255) NOT NULL AUTO_INCREMENT,
  `gift_thumb_url` varchar(2083) NOT NULL,
  `gift_name` varchar(50) NOT NULL,
  `gift_scores` decimal(5,2) NOT NULL,
  PRIMARY KEY (`gift_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Дамп данных таблицы `gift`
--

INSERT INTO `gift` (`gift_id`, `gift_thumb_url`, `gift_name`, `gift_scores`) VALUES
(1, 'http://localhost/azs-app/public/img/gifts/green.png', 'Green gift', 100.00),
(2, 'http://localhost/azs-app/public/img/gifts/light.png', 'Light gift', 50.00),
(3, 'http://localhost/azs-app/public/img/gifts/yellow.png', 'Yellow', 150.00);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
